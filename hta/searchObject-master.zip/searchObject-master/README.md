# searchObject


searchObject is written in C#, using  *visual studio*.
This is developed to search cognos model files **model.xml**.

Here's image of UI for this tool:

![alt text][image]

[image]: https://raw.githubusercontent.com/SanjeetSk/searchObject/master/image.JPG "Logo Title Text 2"
Here's our logo (hover to see the title text):
