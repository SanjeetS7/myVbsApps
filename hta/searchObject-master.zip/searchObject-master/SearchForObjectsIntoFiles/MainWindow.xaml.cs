﻿using System;
using System.Drawing;
using System.IO;
using System.Diagnostics;
using System.Windows.Forms;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;
using System.Xml;
using System.Xml.XPath;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SearchForObjectsIntoFiles
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public List<string> ListOfData = new List<string>();
        int index = 0;
        
        public MainWindow()
        {
            InitializeComponent();
        }

        private void browse_Click(object sender, RoutedEventArgs e)
        {
            FolderBrowserDialog fbd = new FolderBrowserDialog();
            DialogResult Path = fbd.ShowDialog();
            string path = fbd.SelectedPath;
            Folder.Text = path;
        }

        private void ClearButton_Click(object sender, RoutedEventArgs e)
        {
            Folder.Text = "";
            Pattern.Text = "";
            RTB.Document.Blocks.Clear();
        }

        private void searchButton_Click(object sender, RoutedEventArgs e)
        {
            //clear all data 
            ListOfData = new List<string>();
            index = 0;
            RTB.Document.Blocks.Clear();
            string path = Folder.Text;
            if (!Directory.Exists(path))
            {
                System.Windows.MessageBox.Show("Cannot find input path! please check if the path entered is correct and try agian","Error",MessageBoxButton.OK,MessageBoxImage.Error);
                return;
            }
            string[] AllFiles = Directory.GetFiles(path, "*.xml", SearchOption.AllDirectories);
            string SearchPattern = Pattern.Text;
            foreach (string file in AllFiles)
            {
                XDocument xdoc = XDocument.Load(file);
                XNamespace ns = "https://afdsl/skdflsk/d";
                //var firstEle = (from el in xdoc.Root.Descendants(ns + "name")
                //               where el.Attribute("locale") != null && el.Attribute("locale").Value == "en" && el.Ancestors().Descendants(ns + "queryItem").Descendants(ns + "hello").FirstOrDefault().Value == SearchPattern
                //               select "Project:- " + el.Value).First();
                var ele = (from el in xdoc.Root.Descendants(ns + "name")
                          where el.Attribute("locale") != null && el.Attribute("locale").Value == "en" && el.Ancestors().Descendants(ns + "queryItem").Descendants(ns + "hello").FirstOrDefault().Value == SearchPattern
                          select el.Parent.Name.LocalName + ":- " + el.Value).ToList();
                if (ele.Count > 0)
                {
                    var projectName = ele[0].Replace("namespace", "Project");
                    var Namespace = "";
                    string stringToAdd = file + "#" + projectName + "#";
                    for (int i = 1; i < ele.Count; i++)
                    {
                        var item = ele[i];
                        if (item.Contains("namespace") && i > 0)
                        {
                            Namespace = item;
                            stringToAdd += Namespace + "#";
                        }
                        else if (item.Contains("queryItem") && i != ele.Count - 1)
                        {
                            stringToAdd += item + "#";
                            ListOfData.Add(stringToAdd);
                            if (i + 1 < ele.Count)
                            {
                                if (ele[i + 1].Contains("querySubject"))
                                {
                                    stringToAdd = file + "#" + projectName + "#" + Namespace + "#";
                                }
                                else
                                {
                                    stringToAdd = file + "#" + projectName + "#";
                                }
                            }
                        }
                        else
                        {
                            stringToAdd += item + "#";
                        }
                    }
                    ListOfData.Add(stringToAdd);
                    //ListOfData.Add(file);
                }
            }
            if (ListOfData.Count() > 0)
            {
                string[] data = ListOfData[0].Split('#');
                foreach (var item in data)
                {
                    RTB.AppendText(item + "\r");
                }
                //List<string> theData = getData(ListOfData[0], SearchPattern);
                //RTB.AppendText(ListOfData[0] + "\r");
                //var projectName = "";
                //var Namespace = "";
                //for (int i = 0; i < theData.Count; i++)
                //{
                //    var item = theData[i];
                //    if (i == 0 && item.Contains("namespace"))
                //    {
                //        projectName = item.Replace("namespace", "Project");
                //        RTB.AppendText(projectName + "\r");
                //    }
                //    else if (item.Contains("namespace") && i > 0)
                //    {
                //        Namespace = item;
                //        if(i != 1)
                //            RTB.AppendText(projectName + "\r");
                //        RTB.AppendText(item + "\r");
                //    }
                //    else if (item.Contains("queryItem") && i != theData.Count - 1)
                //    {
                //        RTB.AppendText(item + "\r");
                //        RTB.AppendText("next>\r");
                //        RTB.AppendText("\r");
                //        if (i + 1 < theData.Count)
                //        {
                //            if (theData[i+1].Contains("querySubject"))
                //            {
                //                RTB.AppendText(projectName + "\r");
                //                RTB.AppendText(Namespace + "\r");
                //            }
                //        }
                //    }
                //    else
                //    {
                //        RTB.AppendText(item + "\r");
                //    }
                //}
                    //foreach (var item in theData)
                    //{
                    //    RTB.AppendText(item + "\r");
                    //}
            }
            else
            {
                System.Windows.MessageBox.Show("Cannot Find instance of \"" + SearchPattern + "\" in the files!", "Info", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }
        private void Button_Click_1(object sender, RoutedEventArgs e)//previous
        {
            int i = index - 1;
            if (RTB.Document.Blocks.Count < 1)
            {
                System.Windows.MessageBox.Show("No Files to work with", "Error", MessageBoxButton.OK, MessageBoxImage.Stop);
                return;
            }
            if (i < 0)
            {
                System.Windows.MessageBox.Show("This is the First Record!", "Info", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            else
            {
                RTB.Document.Blocks.Clear();
                string[] data = ListOfData[i].Split('#');
                foreach (var item in data)
                {
                    RTB.AppendText(item + "\r");
                }
                //file = ListOfData[i];
                //List<string> theData = getData(file, Pattern.Text);
                //RTB.AppendText(file + "\r");
                //var projectName = "";
                //var Namespace = "";
                //for (int l = 0; l < theData.Count; l++)
                //{
                //    var item = theData[l];
                //    if (l == 0 && item.Contains("namespace"))
                //    {
                //        projectName = item.Replace("namespace", "Project");
                //        RTB.AppendText(projectName + "\r");
                //    }
                //    else if (item.Contains("namespace") && l > 0)
                //    {
                //        Namespace = item;
                //        if (l != 1)
                //            RTB.AppendText(projectName + "\r");
                //        RTB.AppendText(item + "\r");
                //    }
                //    else if (item.Contains("queryItem") && l != theData.Count - 1)
                //    {
                //        RTB.AppendText(item + "\r");
                //        RTB.AppendText("next>\r");
                //        if (l + 1 < theData.Count)
                //        {
                //            if (theData[l + 1].Contains("querySubject"))
                //            {
                //                RTB.AppendText(projectName + "\r");
                //                RTB.AppendText(Namespace + "\r");
                //            }
                //        }
                //    }
                //    else
                //    {
                //        RTB.AppendText(item + "\r");
                //    }
                //}
                index--;
            }
        }
        private List<string> getData(string path, string SearchPattern)
        {
            XDocument xdoc = XDocument.Load(path);
            XNamespace ns = "https://afdsl/skdflsk/d";
            var ele = (from el in xdoc.Root.Descendants(ns + "name")
                       where el.Attribute("locale") != null && el.Attribute("locale").Value == "en" && el.Ancestors().Descendants(ns + "queryItem").Descendants(ns + "hello").FirstOrDefault().Value == SearchPattern
                       select el.Parent.Name.LocalName + ":- " + el.Value).ToList();
            return ele;
        }

        private void Next_Click(object sender, RoutedEventArgs e)//next
        {
            int i = index + 1;
            if (RTB.Document.Blocks.Count < 1)
            {
                System.Windows.MessageBox.Show("No Files to work with","Error", MessageBoxButton.OK, MessageBoxImage.Stop);
                return;
            }
            if (i > ListOfData.Count() - 1)
            {
                System.Windows.MessageBox.Show("This is the Last Record!", "Info", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            else
            {
                RTB.Document.Blocks.Clear();
                string[] data = ListOfData[i].Split('#');
                foreach (var item in data)
                {
                    RTB.AppendText(item + "\r");
                }
                index++;
            }
        }
    }
}
